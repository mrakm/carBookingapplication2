import languageJson from './language.json';

// Goto https://www.w3schools.com/JSREF/jsref_tolocalestring.asp to find the date style for your country.
export const dateStyle= 'en-US';

export const language = languageJson;